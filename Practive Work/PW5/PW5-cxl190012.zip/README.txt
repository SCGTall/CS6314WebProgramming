1.Database name:	SSA

2.Screenshots are in the folder:	/screenshot

3.The table will not show until the submit button is firstly clicked.

4.The select will keep last selected option.