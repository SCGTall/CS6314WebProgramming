<?php
$username="root";
$password="root";
$database="SSA";
?>